<?php

/**
 * @file
 * Test version of default.settings.php from drupal/core.
 */
